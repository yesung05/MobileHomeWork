package com.example.first;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    CheckBox enab;
    CheckBox click;
    CheckBox rot;
    Button bt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        enab = (CheckBox) findViewById(R.id.enable);
        click = (CheckBox) findViewById(R.id.clickable);
        rot = (CheckBox) findViewById(R.id.rotate);
        bt1 = (Button) findViewById(R.id.button);
        enab.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Detect if the "Enable" checkbox is checked or unchecked
                if (isChecked) {
                    click.setVisibility(View.VISIBLE);
                    rot.setVisibility(View.VISIBLE);
                    bt1.setVisibility(View.VISIBLE);
                } else {
                    click.setVisibility(View.INVISIBLE);
                    rot.setVisibility(View.INVISIBLE);
                    bt1.setVisibility(View.INVISIBLE);
                }
            }
        });

        click.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Detect if the "Enable" checkbox is checked or unchecked
                if (isChecked) {
                    bt1.setEnabled(true);
                } else {
                    bt1.setEnabled(false);
                }
            }
        });

        rot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Detect if the "Enable" checkbox is checked or unchecked
                if (isChecked) {
                    bt1.setRotation(45);
                } else {
                    bt1.setRotation(0);
                }
            }
        });
    }
}